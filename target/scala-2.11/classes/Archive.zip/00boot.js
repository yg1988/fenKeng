function cp(){};
function ScalaJSBundle(){};
ScalaJS.modules.example_ScalaJSExample().main();